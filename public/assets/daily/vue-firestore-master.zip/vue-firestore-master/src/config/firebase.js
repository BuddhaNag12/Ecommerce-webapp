export default {
    apiKey: "AIzaSyDqWiLTTtAp_jDlkPAVLQWZe7JPPRdI5ZM",
    authDomain: "coursevuefirestore.firebaseapp.com",
    databaseURL: "https://coursevuefirestore.firebaseio.com",
    projectId: "coursevuefirestore",
    storageBucket: "coursevuefirestore.appspot.com",
    messagingSenderId: "488122186222"
};