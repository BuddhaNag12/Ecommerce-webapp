<template>
	<v-footer height="auto">
		<v-card flat tile class="indigo lighten-1 white--text text-xs-center">
			<v-card-text class="white--text pt-4">
          		Cloud Firestore es una base de datos flexible y escalable para la programación en servidores, dispositivos móviles y la Web desde Firebase y Google Cloud Platform. Al igual que Firebase Realtime Database, mantiene tus datos sincronizados entre apps cliente a través de agentes de escucha en tiempo real y ofrece asistencia sin conexión para dispositivos móviles y la Web, por lo que puedes compilar apps con capacidad de respuesta que funcionan sin importar la latencia de la red ni la conectividad a Internet. Cloud Firestore también ofrece una integración sin interrupciones con otros productos de Firebase y Google Cloud Platform, incluido Cloud Functions.
        	</v-card-text>
        	<v-card-text class="white--text">
          		&copy;2018 — <strong>Vuetify - Aleverarise</strong>
        	</v-card-text>
		</v-card>
	</v-footer>
</template>

<script>
export default {
	name: "app-footer",

	data() {
		return {};
	}
};
</script>

<style lang="css" scoped>
</style>
